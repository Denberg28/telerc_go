# Mini Rover 1.2.4 Go qualification

Baseline: `69f2397`, Mini Rover 1.2.3-mx1508-95pct. Scope: the standalone Wi-Fi sketch in this repository; no Android APK change. Compatibility target: TeleRC Go v1.0.3. The old firmware reports zero custom mode and no ownership/capability message, which GoLink rejects. It already maps all four motors correctly; no physical root cause for one moving wheel is claimed.

| Gate | Status | Evidence and limit |
| --- | --- | --- |
| A source/build | PASS — build verified | Arduino-ESP32 3.3.2, actual ESP32-S3 target, Hardware CDC/JTAG + CDC-on-boot; final build receipt in download |
| B behavior | PASS — host tested | Forward/reverse/both pivots/combined inputs; eight PWM pin/channel allocations; each attachment failure, running and idle register fault; partial-bank detach; neutral dwell, manual ARM, force-ARM rejection, reversal coast |
| C regression | PASS — host tested, leak gate BLOCKED locally | Arduino APIs 2/3 modeled; five driver profiles; ASan/UBSan passes with `ASAN_OPTIONS=detect_leaks=0`. Default LeakSanitizer fails to inspect `/proc/.../task` under this container. CI retains default leak detection |
| D integration | PASS — protocol tested; physical NOT TESTED | Actual sketch packet handler exercises Go-compatible boot ID, exact ownership message/CRC/flags, 31010 acquisition, fallback port and peer lock, release/disconnect/watchdog/reconnect. Real Android/Wi-Fi not available |
| E hardware | BLOCKED | No ESP32, MX1508, motors or measurement equipment attached; follow procedure below |
| F package | PASS — packaged candidate | Sketch, source commit, build settings, compiled image, flash instructions, source manifest and SHA-256; no stable qualification |

Run `tests/run.sh` and `SANITIZE=1 tests/run.sh` on Linux with g++. Actual-board build: install Arduino-ESP32 3.3.2, then `scripts/build.sh` or set `ARDUINO_CLI` to the CLI path. The host API-2 model is not an Arduino-ESP32 2.x board build. Alternate driver profiles are source options covered by host checks; the supplied binary is four-motor MX1508 only.

## Restrained-wheel acceptance

1. Remove motor power, raise and secure all four wheels clear of the table and identify LF/LR/RF/RR. Check one motor per driver channel, GPIO4/5, 6/7, 8/9, 10/11 and common ground. Confirm supplies are within the actual ratings. Photograph wiring before changing it.
2. Flash the new sketch/image with motor power disconnected. Open serial at 115200. Require `v=1.2.4-go-4wd`, four motors, `mask=ff`, `ready=1`, `err=0`, `readErr=0`. All outputs must remain off before ARM.
3. Restore motor power. Join TeleRC-MiniRover, connect Go to 192.168.4.1:14550, system 1. Require Connected, centered sticks and explicit ARM. No wheel may start merely from connect/reconnect. Start at low sensitivity; increase only as needed to overcome unloaded motor friction.
4. At 100% app Drive sensitivity, briefly command full forward with steering centered. Require four equal signed demands, expected `242,0` on all four PWM pairs, and all four wheels turning forward. Repeat reverse; both pairs per motor must never be driven high together. Correct wheel inversion with power removed. Verify both steering pivots, then combined steer/drive.
5. If only one wheel moves, compare `OUT` and `PWM` for all four slots. Correct registers with stationary wheels require checking wiring, actual GPIO signals, driver supply under load and motor/driver channels. To isolate a motor, power down and swap it onto a confirmed working driver channel, then repeat raised-wheel test. Do not infer a working driver from software readback alone.
6. Verify DISARM, BOOT stop, phone disconnect and Wi-Fi removal each stop every wheel. Measure the actual last-command-to-stop delay: nominal control expiry is 500 ms plus scheduling/output latency. After expiry/reconnect, movement must require a new centered dwell and manual ARM. Reboot must remain disarmed and Go must detect the new boot ID.
7. Inspect the serial line under slow/absent USB logging and sustained four-wheel motion. No unexplained `PWM_READBACK`, `PWM_ERROR`, reboot or partial output is acceptable. Record supply minimum and reset reason if motor load causes a restart.
8. Only after raised-wheel acceptance, perform low-speed floor testing with a reachable physical power disconnect. Record firmware commit, app version, supplies, driver labels, pin map, wheel direction, PWM, measured stopping delay and outcome.

## Installation and rollback

Prefer Arduino IDE upload of the complete sketch directory, or flash the packaged merged image at address 0x0 using the provided instructions. Flashing the bootloader/partition image replaces the firmware installation. The default sketch declares a 5 V motor supply and 6 V motors; the binary cannot validate actual voltages.

To roll back, use source at `69f2397` and rebuild with the same toolchain. The previous 1.2.3 firmware does not meet Go v1.0.3's handshake; use the previous matching controller while diagnosing, or retain the last hardware-verified firmware/controller pair. Do not flash the separate TT Car or balancing profile onto this 4WD rover.

Next concrete check: upload with wheels raised, confirm Go Connect/ARM, then compare the four PWM pairs to physical wheel movement. This is necessary to resolve the reported one-wheel symptom.
