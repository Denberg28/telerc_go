# Install 1.2.4-go-4wd

Disconnect motor power before upload. This binary is for ESP32-S3 + two MX1508 boards + four TT drive motors. It is Wi-Fi only.

Option A — Arduino IDE: open TeleRC_MiniRover_WiFi/TeleRC_MiniRover_WiFi.ino with every adjacent header present. Install esp32 core 3.3.2. Board: ESP32S3 Dev Module; USB Mode: Hardware CDC and JTAG; USB CDC On Boot: Enabled. Upload to the actual connected board port.

Option B — compiled merged binary: install Python and esptool 5.1.0, open a terminal in this package, and replace COM9 below with the actual ESP32 port. Close the serial monitor first. The merged image includes bootloader, partition table and application and must start at 0x0. It uses the board default 4 MiB flash configuration (also fits larger ESP32-S3 flash).

    python -m pip install esptool==5.1.0
    python -m esptool --chip esp32s3 --port COM9 --baud 460800 write-flash 0x0 firmware/TeleRC_MiniRover_WiFi.ino.merged.bin

If automatic boot entry fails, hold BOOT, briefly press RESET, release BOOT and retry. Then reset to run. For an Arduino IDE installation, use the sketch directory; do not use the application-only .bin at 0x0.

After flashing, serial 115200 must show 1.2.4-go-4wd, four motors and mask=ff. Join TeleRC-MiniRover / telerc123. In TeleRC Go v1.0.3 connect to 192.168.4.1:14550, system 1; center both sticks and tap ARM. Keep wheels raised for initial testing. See README and docs/TESTING.md for the motor map, fault diagnosis and rollback.

Expected full forward at 100% app drive sensitivity: OUT=242/242/242/242, PWM=242,0/242,0/242,0/242,0. Software readback is not a motor-motion measurement. If registers are correct but only one motor moves, inspect the motor wiring, both drivers and supply/ground paths. No app update is required for Go v1.0.3.
