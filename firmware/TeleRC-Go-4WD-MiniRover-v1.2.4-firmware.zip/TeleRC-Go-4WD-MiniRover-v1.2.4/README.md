# TeleRC Mini Rover

Latest Wi-Fi mini-rover sketch: **1.2.4-go-4wd**, for **TeleRC Go v1.0.3**, ESP32-S3, four TT drive motors and two MX1508 boards. Updated 22 October 2026. This is four-wheel skid steering: no balancing IMU or separate front steering motor.

Open `TeleRC_MiniRover_WiFi/TeleRC_MiniRover_WiFi.ino` in Arduino IDE. All local headers are beside it. Install Arduino-ESP32 **3.3.2**, select **ESP32S3 Dev Module**, USB Mode **Hardware CDC and JTAG**, USB CDC On Boot **Enabled**. The default is MX1508 and four motors; two-motor builds are rejected. Upload, join Wi-Fi **TeleRC-MiniRover** (password **telerc123**), then Connect in TeleRC Go. Endpoint: **192.168.4.1:14550**, system **1**. Center both sticks, tap ARM, then operate. CH1 steers; CH2 drives forward/reverse. Change the Wi-Fi password in Config.h for your own installation.

| Motor, viewed from behind the rover | ESP32-S3 inputs to MX1508 |
| --- | --- |
| Left front | GPIO4 / GPIO5 |
| Left rear | GPIO6 / GPIO7 |
| Right front | GPIO8 / GPIO9 |
| Right rear | GPIO10 / GPIO11 |

Use one driver output channel per motor. Connect both driver grounds and ESP32 ground together. Use a regulated logic supply for the ESP32 and a motor supply within the actual motor/driver ratings; the firmware's default 5 V declaration is not a voltage measurement or regulator. Reverse a motor's two leads, with power off, if its wheel direction is wrong. BOOT/GPIO0 is the local stop. GPIO21 is the optional status LED.

The Go handshake now reports a nonzero boot ID and `TELERC_OWN` capability/ownership, and accepts command 31010 to acquire phone control while disarmed. It replies to the actual phone UDP port, including Android's fallback port. This is **Wi-Fi only**; it does not implement ELRS takeover.

Motor diagnostics at **115200 baud** report four signed demands (`OUT`), eight PWM registers (`PWM`), attached-channel mask (`mask=ff` for MX1508), ownership and stop reason. Full forward at 100% app drive sensitivity should show `OUT=242/242/242/242` and `PWM=242,0/242,0/242,0/242,0`, subject to any configured inversion/trim. At 95% sensitivity expect approximately 229 duty. Full steering pivots both sides in opposite directions. Register readback cannot prove GPIO voltage, driver power or wheel motion.

If only the left front motor moves while all four demands and PWM pairs are correct, check GPIO6–11 wiring, both driver supplies/grounds and each driver output with power off before changing connections. A partial attachment, write error or unexpected settled register value disables all outputs; a latched PWM fault requires reboot after the cause is corrected. Stale control stops/disarms after 500 ms; reconnect never arms automatically.

Run `tests/run.sh`, `SANITIZE=1 tests/run.sh`, then `scripts/build.sh` with the pinned toolchain. [Validation, restrained-wheel checks and rollback](docs/TESTING.md). [Changes](CHANGELOG.md). The old migration record is retained under `docs/MIGRATION_1.2.3.json`; `SOURCE_MANIFEST.json` describes current source hashes. Hardware validation remains pending.
