#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
cli="${ARDUINO_CLI:-arduino-cli}"
output="${1:-build/mx1508}"
"$cli" compile --fqbn esp32:esp32:esp32s3:USBMode=hwcdc,CDCOnBoot=cdc \
  --build-path "$(pwd)/build/cache-mx1508" --output-dir "$output" \
  TeleRC_MiniRover_WiFi
printf 'ESP32-S3 MX1508 build complete: %s\n' "$output"
