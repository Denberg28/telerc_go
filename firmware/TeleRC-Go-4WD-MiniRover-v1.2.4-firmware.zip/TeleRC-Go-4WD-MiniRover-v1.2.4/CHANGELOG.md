# 1.2.4-go-4wd — 22 October 2026

- Add TeleRC Go v1.0.3 boot identity, ownership/capability telemetry and explicit phone-control acquisition.
- Reply to Android fallback UDP source ports while locking control to the discovered peer IP and port.
- Require four motor slots; retain LF 4/5, LR 6/7, RF 8/9, RR 10/11, proportional 95% maximum MX1508 duty and reversal coast.
- Verify all required PWM channels attached; detach every output on a partial attachment.
- Verify settled duty registers even for unchanged commands; latch faults and reject ARM until reboot. Preserve Arduino's 256 full-on representation for TB6612 high-impedance operation.
- Add PWM mask/readback diagnostics, host regressions, a pinned actual-board build and CI.

The previous source's correct four-motor map does not establish why only one physical wheel moved. The Go protocol mismatch is confirmed in source; wiring, driver condition and motor power require hardware checks. This is a build-verified candidate, not a hardware-qualified stable release.
